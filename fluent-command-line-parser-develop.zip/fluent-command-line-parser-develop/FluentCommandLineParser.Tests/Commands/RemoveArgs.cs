﻿using System.Collections.Generic;

namespace Fclp.Tests.Commands
{
    class RemoveArgs
    {
        public bool Verbose { get; set; }
        public List<string> Files { get; set; }
    }
}
