IFix
====

See instructions for use here:  
https://github.com/OsirisTerje/IFix/wiki

Blogpost on nugetrestore command: http://geekswithblogs.net/terje/archive/2014/06/11/converting-projects-to-use-automatic-nuget-restore.aspx 

Blogpost on gitignore command:
http://geekswithblogs.net/terje/archive/2014/06/13/fixing-up-visual-studiorsquos-gitignore--using-ifix.aspx



Download binary setup from: http://visualstudiogallery.msdn.microsoft.com/b8ba97b0-bb89-4c21-a1e2-53ef335fd9cb

For building:

Requires: 
Wix 3.8
.Net 4.5.1
To build use Visual Studio 2017 Update 3 

Latest build
[![Build Status](https://terjedemo.visualstudio.com/_apis/public/build/definitions/1c2183f6-7be6-4865-a8a1-5de2b16cf629/13/badge)]

